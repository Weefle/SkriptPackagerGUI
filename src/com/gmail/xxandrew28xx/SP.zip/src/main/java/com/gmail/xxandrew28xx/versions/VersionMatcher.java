package main.java.com.gmail.xxandrew28xx.versions;

public interface VersionMatcher {
	boolean matches(String version);
}
