package main.java.com.gmail.xxandrew28xx;

import ch.njol.skript.ScriptLoader;
import ch.njol.util.OpenCloseable;

import java.io.File;

public class Skript {
	public static void loadScript(File... f){
		ScriptLoader.loadScripts(ScriptLoader.loadStructures(f));
	}
}
